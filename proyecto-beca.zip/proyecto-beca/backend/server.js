const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

// ==========================================
//   SERVIR ARCHIVOS ESTÁTICOS (todo local)
// ==========================================
const FRONTEND = path.join(__dirname, '..', 'frontend');
app.use(express.static(FRONTEND));
app.use('/lib', express.static(path.join(FRONTEND, 'lib')));
app.use('/modelos', express.static(path.join(FRONTEND, 'modelos')));

// ==========================================
//   BASE DE DATOS
// ==========================================
const db = new Database(path.join(__dirname, 'beca.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS beneficiarios (
    matricula  TEXT PRIMARY KEY,
    nombre     TEXT NOT NULL,
    descriptor TEXT NOT NULL,
    activo     INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS entregas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    matricula  TEXT NOT NULL,
    fecha      TEXT DEFAULT CURRENT_TIMESTAMP,
    confianza  REAL,
    FOREIGN KEY (matricula) REFERENCES beneficiarios(matricula)
  );
`);

function distancia(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += (a[i] - b[i]) ** 2;
  return Math.sqrt(s);
}

// ==========================================
//   ENDPOINTS
// ==========================================
app.post('/api/registrar', (req, res) => {
  const { matricula, nombre, descriptor } = req.body;
  if (!matricula || !nombre || !Array.isArray(descriptor)) {
    return res.status(400).json({ ok: false, error: 'Datos incompletos' });
  }
  try {
    db.prepare(
      'INSERT OR REPLACE INTO beneficiarios (matricula, nombre, descriptor) VALUES (?, ?, ?)'
    ).run(matricula, nombre, JSON.stringify(descriptor));
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/validar', (req, res) => {
  const { descriptor } = req.body;
  if (!Array.isArray(descriptor)) {
    return res.status(400).json({ ok: false, error: 'Descriptor inválido' });
  }
  const lista = db.prepare(
    'SELECT matricula, nombre, descriptor FROM beneficiarios WHERE activo = 1'
  ).all();

  if (lista.length === 0) return res.json({ ok: false, error: 'Sin beneficiarios' });

  const UMBRAL = 0.5;
  let mejor = null, mejorDist = Infinity;

  for (const b of lista) {
    const d = distancia(descriptor, JSON.parse(b.descriptor));
    if (d < mejorDist) { mejorDist = d; mejor = b; }
  }

  if (mejor && mejorDist < UMBRAL) {
    const conf = 1 - mejorDist;
    db.prepare('INSERT INTO entregas (matricula, confianza) VALUES (?, ?)')
      .run(mejor.matricula, conf);
    console.log(`✅ ${mejor.nombre} (${(conf*100).toFixed(1)}%)`);
    return res.json({
      ok: true, matricula: mejor.matricula,
      nombre: mejor.nombre, confianza: conf
    });
  }
  console.log(`❌ No reconocido (dist: ${mejorDist.toFixed(3)})`);
  res.json({ ok: false, error: 'No reconocido' });
});

app.get('/api/beneficiarios', (req, res) => {
  res.json(db.prepare('SELECT matricula, nombre, activo FROM beneficiarios').all());
});

app.get('/api/entregas/:matricula', (req, res) => {
  res.json(db.prepare(
    'SELECT * FROM entregas WHERE matricula = ? ORDER BY fecha DESC'
  ).all(req.params.matricula));
});

// ==========================================
//   ARRANCAR
// ==========================================
const PUERTO = 3000;
app.listen(PUERTO, '0.0.0.0', () => {
  console.log(`\n🚀 Servidor local activo`);
  console.log(`   Kiosco:  http://localhost:${PUERTO}/`);
  console.log(`   Admin:   http://localhost:${PUERTO}/admin.html\n`);
});
