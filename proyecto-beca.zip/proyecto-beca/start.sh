#!/bin/bash
cd "$(dirname "$0")/backend"
echo "🚀 Iniciando sistema de beca..."
node server.js
